import { X, Play, Phone } from 'lucide-react';
import { useState } from 'react';

interface DemoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DemoModal({ isOpen, onClose }: DemoModalProps) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const intervalRef = { current: null as ReturnType<typeof setInterval> | null };

  if (!isOpen) return null;

  const togglePlay = () => {
    if (!playing) {
      const interval = setInterval(() => {
        setProgress(p => {
          if (p >= 100) {
            clearInterval(interval);
            setPlaying(false);
            return 0;
          }
          return p + 0.5;
        });
      }, 100);
      intervalRef.current = interval;
      setPlaying(true);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setPlaying(false);
    }
  };

  const transcript = [
    { speaker: 'Агент', time: '0:00', text: 'Добрый день! Компания СтройПроект, меня зовут Алекс. Как я могу помочь?' },
    { speaker: 'Клиент', time: '0:05', text: 'Здравствуйте, хочу узнать о строительстве дома под ключ.' },
    { speaker: 'Агент', time: '0:09', text: 'Отлично! Расскажите, какую площадь дома вы рассматриваете и есть ли уже земельный участок?' },
    { speaker: 'Клиент', time: '0:15', text: 'Участок есть, хочу около 150 квадратов, одноэтажный.' },
    { speaker: 'Агент', time: '0:21', text: 'Прекрасно! 150 кв.м, одноэтажный — это популярный формат. Какой у вас примерный бюджет на строительство?' },
    { speaker: 'Клиент', time: '0:28', text: 'Рассчитываю на 7-9 миллионов рублей.' },
    { speaker: 'Агент', time: '0:33', text: 'Это реализуемо. Наши проекты в этом бюджете включают монолитный фундамент, газобетон, утепление и чистовую отделку. Когда планируете начать?' },
    { speaker: 'Клиент', time: '0:42', text: 'Хотелось бы начать весной следующего года.' },
    { speaker: 'Агент', time: '0:47', text: 'Весна — отличное время для закладки фундамента. Записать вас на встречу с нашим архитектором? Он покажет готовые проекты и сделает расчёт.' },
  ];

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      <div className="modal-backdrop absolute inset-0" onClick={onClose} />
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl z-10 max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-900 rounded-t-3xl">
          <div>
            <h3 className="text-white font-black text-lg">🎙️ Демо звонок ИИ-агента</h3>
            <p className="text-gray-400 text-sm">Реальная запись разговора · Строительная компания</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center hover:bg-gray-600 transition-colors">
            <X size={16} className="text-white" />
          </button>
        </div>

        {/* Audio player */}
        <div className="bg-gray-900 px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={togglePlay}
              className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors flex-shrink-0"
            >
              {playing ? (
                <div className="flex gap-1">
                  <div className="w-1 h-4 bg-white rounded" />
                  <div className="w-1 h-4 bg-white rounded" />
                </div>
              ) : (
                <Play size={18} className="text-white ml-0.5" />
              )}
            </button>
            <div className="flex-1">
              <div className="flex justify-between text-xs text-gray-400 mb-1.5">
                <span>Длительность: 1:23</span>
                <span>{Math.round(progress / 100 * 83)}с / 83с</span>
              </div>
              <div className="relative h-2 bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="absolute inset-y-0 left-0 bg-blue-500 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Transcript */}
        <div className="flex-1 overflow-y-auto p-6">
          <h4 className="font-bold text-gray-700 text-sm mb-4">📝 Транскрипция разговора:</h4>
          <div className="space-y-3">
            {transcript.map((line, i) => (
              <div
                key={i}
                className={`flex gap-3 p-3 rounded-xl transition-colors ${
                  playing && Math.round(progress / 100 * 83) >= parseInt(line.time.split(':')[1]) + parseInt(line.time.split(':')[0]) * 60
                    ? line.speaker === 'Агент' ? 'bg-blue-50 border border-blue-100' : 'bg-gray-50'
                    : 'opacity-60'
                }`}
              >
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full h-fit flex-shrink-0 ${
                  line.speaker === 'Агент' ? 'bg-blue-100 text-blue-700' : 'bg-gray-200 text-gray-600'
                }`}>
                  {line.speaker}
                </span>
                <div className="flex-1">
                  <span className="text-xs text-gray-400 mr-2">{line.time}</span>
                  <span className="text-sm text-gray-800">{line.text}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-100 p-4 flex gap-3">
          <a
            href="tel:+74951234567"
            className="flex-1 flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-xl font-bold hover:bg-green-600 transition-colors text-sm"
          >
            <Phone size={16} /> Позвонить ИИ прямо сейчас
          </a>
          <button
            onClick={onClose}
            className="px-5 py-3 border-2 border-gray-200 text-gray-600 rounded-xl font-semibold hover:bg-gray-50 transition-colors text-sm"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
}
