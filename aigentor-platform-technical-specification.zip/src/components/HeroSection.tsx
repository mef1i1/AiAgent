import { useEffect, useState } from 'react';
import HeroCanvas from './HeroCanvas';
import { Play, Phone, Users, TrendingUp, Shield, Star } from 'lucide-react';

interface HeroProps {
  onOpenForm: () => void;
  onOpenDemo: () => void;
}

const floatingIcons = [
  { icon: Phone, label: 'Звонки', color: 'bg-blue-100 text-blue-600', pos: 'top-[12%] right-[28%]', delay: '0s' },
  { icon: Users, label: 'CRM', color: 'bg-purple-100 text-purple-600', pos: 'top-[8%] right-[12%]', delay: '1s' },
  { icon: TrendingUp, label: 'Аналитика', color: 'bg-cyan-100 text-cyan-600', pos: 'top-[42%] right-[6%]', delay: '2s' },
  { icon: Shield, label: 'Безопасность', color: 'bg-green-100 text-green-600', pos: 'bottom-[22%] right-[22%]', delay: '1.5s' },
  { icon: Star, label: 'ИИ', color: 'bg-orange-100 text-orange-600', pos: 'top-[55%] right-[38%]', delay: '0.5s' },
];

const stats = [
  { value: '20+', label: 'ИИ-агентов в экосистеме', icon: '🤖' },
  { value: '24/7', label: 'Непрерывная работа', icon: '⏰' },
  { value: '3-10x', label: 'Рост эффективности', icon: '📈' },
  { value: '100+', label: 'Довольных клиентов', icon: '⭐' },
  { value: '99.9%', label: 'Точность и надёжность', icon: '🛡️' },
];

export default function HeroSection({ onOpenForm, onOpenDemo }: HeroProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section id="hero" className="relative min-h-screen hero-bg overflow-hidden flex flex-col">
      <HeroCanvas />

      {/* Decorative circles */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200/30 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-200/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-16 flex-1 flex flex-col justify-center">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[600px]">
          {/* Left column */}
          <div className={`transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-6">
              <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              ИИ АГЕНТЫ ДЛЯ ВАШЕГО БИЗНЕСА
            </div>

            {/* H1 */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-gray-900 leading-[1.1] mb-6">
              Автоматизация бизнеса с помощью{' '}
              <span className="gradient-text">ИИ-агентов.</span>
              <br />
              <span className="text-gray-700 text-3xl md:text-4xl lg:text-5xl font-bold">Без ботов и скриптов.</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg text-gray-600 mb-4 leading-relaxed max-w-lg">
              Создаём цифровых сотрудников, которые берут на себя рутину, повышают эффективность и помогают вашему бизнесу расти.
            </p>
            <p className="text-blue-700 font-bold text-xl mb-8">
              💰 Экономия от <span className="text-2xl">70 000 ₽/мес</span>
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <button
                onClick={onOpenForm}
                className="btn-primary flex items-center justify-center gap-2 group"
              >
                Запустить бесплатный тест
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </button>
              <button
                onClick={onOpenDemo}
                className="btn-secondary flex items-center justify-center gap-2 group hover:bg-blue-50"
              >
                <Play size={18} className="text-blue-600 group-hover:scale-110 transition-transform" />
                Смотреть демо звонка
              </button>
            </div>

            {/* Trust indicators */}
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <Shield size={14} className="text-green-500" />
                <span>152-ФЗ соответствие</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-green-500">✓</span>
                <span>Российские серверы</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-green-500">✓</span>
                <span>Запуск за 3 дня</span>
              </div>
            </div>
          </div>

          {/* Right column - Robot + floating icons */}
          <div className={`relative hidden lg:flex justify-center items-center transition-all duration-1000 delay-300 ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            {/* Main robot image */}
            <div className="relative z-10 animate-float">
              <div className="w-[420px] h-[420px] rounded-3xl overflow-hidden shadow-2xl glow-blue">
                <img
                  src="/images/ai-robot-hero.png"
                  alt="ИИ-агент Aigentor"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Glow ring */}
              <div className="absolute inset-0 rounded-3xl border-2 border-blue-300/50 animate-spin-slow" />
            </div>

            {/* Floating icon cards */}
            {floatingIcons.map(({ icon: Icon, label, color, pos, delay }, i) => (
              <div
                key={i}
                className={`absolute ${pos} floating-icon`}
                style={{ animationDelay: delay }}
              >
                <div className="glass rounded-2xl p-3 shadow-lg flex items-center gap-2">
                  <div className={`w-10 h-10 ${color} rounded-xl flex items-center justify-center`}>
                    <Icon size={20} />
                  </div>
                  <span className="text-sm font-semibold text-gray-700 pr-1">{label}</span>
                </div>
              </div>
            ))}

            {/* Live indicator */}
            <div className="absolute bottom-4 left-4 glass rounded-xl px-4 py-2 flex items-center gap-2 shadow-lg animate-bounce-gentle">
              <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-gray-700">Агент работает 24/7</span>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className={`mt-12 transition-all duration-1000 delay-500 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="glass rounded-2xl p-6 shadow-xl">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
              {stats.map((stat, i) => (
                <div key={i} className="text-center group hover:scale-105 transition-transform">
                  <div className="text-2xl mb-1">{stat.icon}</div>
                  <div className="text-2xl font-black text-blue-600 stat-number">{stat.value}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="relative z-10 flex justify-center pb-8 animate-bounce-gentle">
        <div className="flex flex-col items-center gap-1 text-gray-400">
          <span className="text-xs">Прокрутите вниз</span>
          <div className="w-6 h-10 border-2 border-gray-300 rounded-full flex justify-center pt-1.5">
            <div className="w-1.5 h-3 bg-blue-500 rounded-full animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}
