import { useState } from 'react';
import { BarChart2, Users, Phone, MessageSquare, Settings, ChevronRight } from 'lucide-react';

const screens = [
  { label: 'Дашборд', icon: BarChart2 },
  { label: 'Агенты', icon: Users },
  { label: 'Логи', icon: Phone },
  { label: 'База данных', icon: MessageSquare },
  { label: 'Настройки', icon: Settings },
];

const metricsData = [
  { label: 'Сэкономлено', value: '84 700 ₽', change: '+12%', positive: true },
  { label: 'Звонков', value: '2 147', change: '+8%', positive: true },
  { label: 'Конверсия', value: '23.4%', change: '+3.1%', positive: true },
  { label: 'Баланс', value: '12 500 ₽', change: '-2 100', positive: false },
];

const agentsData = [
  { name: 'Приём звонков — Строительство', type: 'Голосовой', status: 'active', calls: 147 },
  { name: 'Квалификация лидов — Telegram', type: 'Текстовый', status: 'active', calls: 89 },
  { name: 'Email обработка B2B', type: 'Email', status: 'inactive', calls: 0 },
];

const logsData = [
  { time: '14:23', type: 'Звонок', client: 'Иван П.', status: 'Успешно', agent: 'Агент #1' },
  { time: '14:18', type: 'Telegram', client: 'Мария С.', status: 'Лид', agent: 'Агент #2' },
  { time: '14:05', type: 'Звонок', client: 'Алексей К.', status: 'Перезвонить', agent: 'Агент #1' },
  { time: '13:57', type: 'WhatsApp', client: 'Ольга В.', status: 'Успешно', agent: 'Агент #2' },
];

function DashboardScreen() {
  return (
    <div className="p-4 space-y-4">
      <div className="grid grid-cols-2 gap-3">
        {metricsData.map((m, i) => (
          <div key={i} className="bg-gray-50 rounded-xl p-3">
            <div className="text-xs text-gray-500 mb-1">{m.label}</div>
            <div className="text-lg font-black text-gray-900">{m.value}</div>
            <div className={`text-xs font-semibold ${m.positive ? 'text-green-500' : 'text-red-500'}`}>
              {m.change}
            </div>
          </div>
        ))}
      </div>
      {/* Mini chart */}
      <div className="bg-gray-50 rounded-xl p-3">
        <div className="text-xs text-gray-500 mb-2">Активность за 7 дней</div>
        <div className="flex items-end gap-1 h-16">
          {[40, 65, 45, 80, 60, 90, 75].map((h, i) => (
            <div
              key={i}
              className="flex-1 rounded-t bg-blue-500 transition-all"
              style={{ height: `${h}%`, opacity: 0.7 + i * 0.04 }}
            />
          ))}
        </div>
        <div className="flex justify-between text-[10px] text-gray-400 mt-1">
          {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(d => <span key={d}>{d}</span>)}
        </div>
      </div>
      {/* Recent activity */}
      <div>
        <div className="text-xs text-gray-500 mb-2">Последние звонки</div>
        <div className="space-y-1.5">
          {logsData.slice(0, 3).map((log, i) => (
            <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2">
              <div className={`w-2 h-2 rounded-full ${log.status === 'Успешно' ? 'bg-green-500' : log.status === 'Лид' ? 'bg-blue-500' : 'bg-yellow-500'}`} />
              <span className="text-xs text-gray-600 flex-1">{log.client}</span>
              <span className="text-[10px] text-gray-400">{log.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AgentsScreen() {
  return (
    <div className="p-4 space-y-3">
      {agentsData.map((agent, i) => (
        <div key={i} className="bg-gray-50 rounded-xl p-3 flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full flex-shrink-0 ${agent.status === 'active' ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`} />
          <div className="flex-1 min-w-0">
            <div className="text-xs font-bold text-gray-800 truncate">{agent.name}</div>
            <div className="text-[10px] text-gray-400">{agent.type} · {agent.calls} сегодня</div>
          </div>
          <label className="toggle flex-shrink-0">
            <input type="checkbox" defaultChecked={agent.status === 'active'} />
            <span className="toggle-slider" />
          </label>
        </div>
      ))}
    </div>
  );
}

function LogsScreen() {
  return (
    <div className="p-4">
      <div className="space-y-2">
        {logsData.map((log, i) => (
          <div key={i} className="bg-gray-50 rounded-xl p-3 flex items-center gap-2">
            <div className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              log.status === 'Успешно' ? 'bg-green-100 text-green-700' :
              log.status === 'Лид' ? 'bg-blue-100 text-blue-700' :
              'bg-yellow-100 text-yellow-700'
            }`}>
              {log.status}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-gray-800">{log.client}</div>
              <div className="text-[10px] text-gray-400">{log.type}</div>
            </div>
            <span className="text-[10px] text-gray-400 flex-shrink-0">{log.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function DashboardPreview({ onOpenForm }: { onOpenForm: () => void }) {
  const [activeScreen, setActiveScreen] = useState(0);

  const renderScreen = () => {
    switch (activeScreen) {
      case 0: return <DashboardScreen />;
      case 1: return <AgentsScreen />;
      case 2: return <LogsScreen />;
      default: return <DashboardScreen />;
    }
  };

  return (
    <section className="py-24 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Text */}
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-6">
              Личный кабинет
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-6">
              Вам не нужно<br />
              <span className="gradient-text">быть программистом</span>
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Мы настраиваем всё за вас. Вы получаете готовый инструмент контроля: смотрите звонки, читаете транскрипции, следите за метриками.
            </p>

            <div className="space-y-4 mb-8">
              {[
                { emoji: '📊', title: 'Аналитика в реальном времени', desc: 'Метрики, графики, конверсия' },
                { emoji: '🎙️', title: 'Полные транскрипции звонков', desc: 'Текст + аудио + временные метки' },
                { emoji: '🔗', title: 'Интеграции с CRM и телефонией', desc: 'amoCRM, Bitrix24, Mango Office' },
                { emoji: '💰', title: 'Управление балансом', desc: 'Прозрачная тарификация, счета' },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-4 p-4 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow card-hover">
                  <span className="text-2xl">{item.emoji}</span>
                  <div>
                    <p className="font-bold text-gray-900">{item.title}</p>
                    <p className="text-gray-500 text-sm">{item.desc}</p>
                  </div>
                  <ChevronRight size={16} className="text-gray-400 ml-auto mt-1 flex-shrink-0" />
                </div>
              ))}
            </div>

            <button
              onClick={onOpenForm}
              className="btn-primary flex items-center gap-2"
            >
              Авторизоваться или Зарегистрироваться →
            </button>
          </div>

          {/* Right: Dashboard mockup */}
          <div className="relative">
            {/* Browser frame */}
            <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
              {/* Browser bar */}
              <div className="bg-gray-100 px-4 py-3 flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 bg-red-400 rounded-full" />
                  <div className="w-3 h-3 bg-yellow-400 rounded-full" />
                  <div className="w-3 h-3 bg-green-400 rounded-full" />
                </div>
                <div className="flex-1 bg-white rounded-lg px-3 py-1 text-xs text-gray-400 text-center">
                  app.aigentor.ru
                </div>
              </div>

              {/* App layout */}
              <div className="flex h-[420px]">
                {/* Sidebar */}
                <div className="w-14 bg-gray-900 flex flex-col items-center py-4 gap-2">
                  <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
                    <span className="text-white font-black text-sm">A</span>
                  </div>
                  {screens.map((screen, i) => {
                    const Icon = screen.icon;
                    return (
                      <button
                        key={i}
                        onClick={() => setActiveScreen(i)}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                          activeScreen === i ? 'bg-blue-600 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                        }`}
                        title={screen.label}
                      >
                        <Icon size={16} />
                      </button>
                    );
                  })}
                </div>

                {/* Main content */}
                <div className="flex-1 overflow-hidden bg-white">
                  {/* Top bar */}
                  <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                    <h3 className="font-bold text-gray-900 text-sm">{screens[activeScreen]?.label}</h3>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      <span className="text-xs text-gray-500">Live</span>
                    </div>
                  </div>
                  {/* Content */}
                  <div className="overflow-y-auto h-full">
                    {renderScreen()}
                  </div>
                </div>
              </div>
            </div>

            {/* Floating notification */}
            <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-3 flex items-center gap-2 border border-green-100">
              <div className="w-8 h-8 bg-green-100 rounded-xl flex items-center justify-center text-green-600 font-bold">✓</div>
              <div>
                <p className="text-xs font-bold text-gray-800">Новый лид!</p>
                <p className="text-[10px] text-gray-500">Иван, строительство</p>
              </div>
            </div>

            {/* Screen tabs */}
            <div className="flex justify-center gap-2 mt-4">
              {screens.slice(0, 3).map((s, i) => (
                <button
                  key={i}
                  onClick={() => setActiveScreen(i)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                    activeScreen === i ? 'bg-blue-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-100 border border-gray-200'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
