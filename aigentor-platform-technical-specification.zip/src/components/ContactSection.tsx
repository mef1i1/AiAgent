import { useState } from 'react';
import { Phone, Mail, Send, MapPin, CheckCircle } from 'lucide-react';

const industries = [
  'Строительство', 'Консалтинг', 'Риелторство', 'Услуги',
  'Производство', 'Торговля', 'Медицина', 'Образование', 'Другое'
];

interface ContactProps {
  prefillData?: { calls?: number; salary?: number; savings?: number };
  onClose?: () => void;
}

export default function ContactSection({ prefillData }: ContactProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    industry: '',
    comment: prefillData ? `Ожидаемая экономия: ${prefillData.savings?.toLocaleString('ru-RU')} ₽/мес (${prefillData.calls} звонков, зарплата ${prefillData.salary?.toLocaleString('ru-RU')} ₽)` : '',
    agree: false,
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Введите ваше имя';
    if (!formData.phone.trim() || formData.phone.length < 10) newErrors.phone = 'Введите корректный телефон';
    if (!formData.industry) newErrors.industry = 'Выберите нишу';
    if (!formData.agree) newErrors.agree = 'Необходимо ваше согласие';
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitted(true);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '');
    if (val.startsWith('8')) val = '7' + val.slice(1);
    if (!val.startsWith('7')) val = '7' + val;
    val = val.slice(0, 11);
    let formatted = '+7';
    if (val.length > 1) formatted += ' (' + val.slice(1, 4);
    if (val.length >= 4) formatted += ') ' + val.slice(4, 7);
    if (val.length >= 7) formatted += '-' + val.slice(7, 9);
    if (val.length >= 9) formatted += '-' + val.slice(9, 11);
    setFormData(prev => ({ ...prev, phone: formatted }));
  };

  return (
    <section id="contact" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left: Info */}
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-6">
              Контакты
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-6">
              Готовы делегировать<br />
              <span className="gradient-text">рутину?</span>
            </h2>
            <p className="text-xl text-gray-600 mb-10 leading-relaxed">
              Оставьте заявку и мы свяжемся с вами в течение часа, чтобы обсудить ваш проект и предложить решение.
            </p>

            {/* Contacts */}
            <div className="space-y-5 mb-10">
              <a
                href="tel:+74951234567"
                className="flex items-center gap-4 p-5 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow group"
              >
                <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all">
                  <Phone size={22} />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Телефон</p>
                  <p className="text-xl font-black text-gray-900">+7 (495) 123-45-67</p>
                </div>
              </a>

              <a
                href="mailto:hello@aigentor.ru"
                className="flex items-center gap-4 p-5 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow group"
              >
                <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-all">
                  <Mail size={22} />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Email</p>
                  <p className="text-xl font-black text-gray-900">hello@aigentor.ru</p>
                </div>
              </a>

              <div className="flex items-center gap-4 p-5 bg-white rounded-2xl shadow-sm">
                <div className="w-12 h-12 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center">
                  <MapPin size={22} />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Локация</p>
                  <p className="text-xl font-black text-gray-900">Москва, Россия</p>
                </div>
              </div>
            </div>

            {/* Social icons */}
            <div>
              <p className="text-gray-500 text-sm font-medium mb-3">Мы в соцсетях:</p>
              <div className="flex gap-3">
                {[
                  { label: 'Telegram', href: 'https://t.me/aigentor', bg: 'bg-blue-500', emoji: '✈️' },
                  { label: 'YouTube', href: 'https://youtube.com/@aigentor', bg: 'bg-red-500', emoji: '▶️' },
                  { label: 'Instagram', href: 'https://instagram.com/aigentor', bg: 'bg-pink-500', emoji: '📷' },
                  { label: 'VK', href: 'https://vk.com/aigentor', bg: 'bg-blue-600', emoji: '💙' },
                ].map((s, i) => (
                  <a
                    key={i}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-12 h-12 ${s.bg} text-white rounded-2xl flex items-center justify-center text-xl hover:opacity-90 hover:scale-110 transition-all shadow-md`}
                    title={s.label}
                  >
                    {s.emoji}
                  </a>
                ))}
              </div>
            </div>

            {/* Work hours */}
            <div className="mt-8 p-5 bg-blue-600 rounded-2xl text-white">
              <p className="font-bold mb-1">⏰ Время работы поддержки</p>
              <p className="text-blue-200 text-sm">Пн-Пт: 9:00 — 20:00 МСК</p>
              <p className="text-blue-200 text-sm">Сб-Вс: 10:00 — 17:00 МСК</p>
              <p className="text-blue-300 text-xs mt-2">ИИ-агенты работают 24/7 без выходных</p>
            </div>
          </div>

          {/* Right: Form */}
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full py-16 text-center">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle size={40} />
                </div>
                <h3 className="text-2xl font-black text-gray-900 mb-3">Заявка отправлена!</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Спасибо! Мы свяжемся с вами в течение часа в рабочее время. Уведомление уже отправлено нашему менеджеру.
                </p>
                <div className="bg-blue-50 rounded-2xl p-4 text-left w-full">
                  <p className="text-blue-700 font-semibold text-sm mb-2">Что будет дальше:</p>
                  <div className="space-y-2 text-sm text-blue-600">
                    <p>1. Менеджер позвонит вам</p>
                    <p>2. Проведём демонстрацию за 15 мин</p>
                    <p>3. Запустим бесплатный тест</p>
                  </div>
                </div>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 text-blue-600 font-semibold hover:text-blue-700"
                >
                  Отправить ещё одну заявку
                </button>
              </div>
            ) : (
              <>
                <h3 className="text-2xl font-black text-gray-900 mb-2">Оставить заявку</h3>
                <p className="text-gray-500 text-sm mb-6">Ответим в течение часа в рабочее время</p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Name */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Ваше имя *</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Иван Петров"
                      className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none focus:border-blue-500 ${
                        errors.name ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'
                      }`}
                    />
                    {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Номер телефона *</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={handlePhoneChange}
                      placeholder="+7 (___) ___-__-__"
                      className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none focus:border-blue-500 ${
                        errors.phone ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'
                      }`}
                    />
                    {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                  </div>

                  {/* Industry */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Ниша бизнеса *</label>
                    <select
                      value={formData.industry}
                      onChange={e => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                      className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none focus:border-blue-500 bg-gray-50 ${
                        errors.industry ? 'border-red-300' : 'border-gray-200'
                      }`}
                    >
                      <option value="">Выберите отрасль</option>
                      {industries.map(ind => (
                        <option key={ind} value={ind}>{ind}</option>
                      ))}
                    </select>
                    {errors.industry && <p className="text-red-500 text-xs mt-1">{errors.industry}</p>}
                  </div>

                  {/* Comment */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Комментарий</label>
                    <textarea
                      value={formData.comment}
                      onChange={e => setFormData(prev => ({ ...prev, comment: e.target.value }))}
                      placeholder="Расскажите о вашем бизнесе и задаче..."
                      rows={3}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-gray-50 transition-colors focus:outline-none focus:border-blue-500 resize-none"
                    />
                  </div>

                  {/* Agreement */}
                  <div>
                    <label className={`flex items-start gap-3 cursor-pointer group ${errors.agree ? 'text-red-500' : ''}`}>
                      <div className="relative flex-shrink-0 mt-0.5">
                        <input
                          type="checkbox"
                          checked={formData.agree}
                          onChange={e => setFormData(prev => ({ ...prev, agree: e.target.checked }))}
                          className="sr-only"
                        />
                        <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                          formData.agree ? 'bg-blue-600 border-blue-600' : errors.agree ? 'border-red-400' : 'border-gray-300 group-hover:border-blue-400'
                        }`}>
                          {formData.agree && <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>}
                        </div>
                      </div>
                      <span className={`text-sm ${errors.agree ? 'text-red-500' : 'text-gray-500'}`}>
                        Я согласен(на) на обработку персональных данных в соответствии с{' '}
                        <a href="#" className="text-blue-600 hover:underline">Политикой конфиденциальности</a>
                      </span>
                    </label>
                    {errors.agree && <p className="text-red-500 text-xs mt-1">{errors.agree}</p>}
                  </div>

                  {/* Submit */}
                  <button
                    type="submit"
                    className="w-full btn-primary flex items-center justify-center gap-2"
                  >
                    <Send size={18} />
                    Оставить заявку
                  </button>

                  <p className="text-center text-gray-400 text-xs">
                    Защищено Google reCAPTCHA · Ваши данные в безопасности
                  </p>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
