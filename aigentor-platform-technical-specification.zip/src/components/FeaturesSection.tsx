import { useEffect, useRef } from 'react';
import { Brain, Globe, Database, Shield, Zap, BarChart2, MessageSquare, Phone } from 'lucide-react';

const features = [
  {
    icon: Brain,
    color: 'bg-blue-100 text-blue-600',
    glow: 'group-hover:shadow-blue-200',
    title: 'Истинный ИИ, а не скрипты',
    description: 'Генеративные ответы на основе реального понимания контекста. Ноль задержек, живая речь, адаптация под любой сценарий диалога.',
    badge: 'GPT-4 уровень',
  },
  {
    icon: Globe,
    color: 'bg-purple-100 text-purple-600',
    glow: 'group-hover:shadow-purple-200',
    title: 'Абсолютная омниканальность',
    description: 'Звонки, Telegram, WhatsApp, email, VK — единая система учёта клиентов. Агент помнит каждый контакт вне зависимости от канала.',
    badge: '5+ каналов',
  },
  {
    icon: Database,
    color: 'bg-cyan-100 text-cyan-600',
    glow: 'group-hover:shadow-cyan-200',
    title: 'Бесшовная интеграция с CRM',
    description: 'Автоматическое занесение данных в amoCRM и Bitrix24. Актуализация статусов в реальном времени без ручного ввода.',
    badge: 'amoCRM · Bitrix24',
  },
  {
    icon: Shield,
    color: 'bg-green-100 text-green-600',
    glow: 'group-hover:shadow-green-200',
    title: 'Полная легальность и 152-ФЗ',
    description: 'Размещение на российских серверах (Yandex Cloud). Полное соответствие законодательству РФ о персональных данных.',
    badge: '152-ФЗ ✓',
  },
];

const capabilities = [
  { icon: Phone, label: 'Обработка звонков', desc: 'ИИ принимает звонки, отвечает на вопросы и записывает клиентов' },
  { icon: Zap, label: 'Квалификация лидов', desc: 'Автоматически собирает информацию и квалифицирует потенциальных клиентов' },
  { icon: MessageSquare, label: 'Поддержка клиентов', desc: 'Отвечает на вопросы 24/7 и помогает решать проблемы клиентов' },
  { icon: BarChart2, label: 'Аналитика и отчёты', desc: 'Собирает данные и формирует понятные отчёты и инсайты' },
  { icon: Brain, label: 'Создание контента', desc: 'Генерирует тексты, изображения и контент для ваших каналов' },
  { icon: Database, label: 'Работа с базами', desc: 'Учёт, поиск, обновление, сегментация клиентских данных' },
];

export default function FeaturesSection({ onOpenForm }: { onOpenForm: () => void }) {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.animate-on-scroll').forEach((el, i) => {
              setTimeout(() => {
                (el as HTMLElement).style.opacity = '1';
                (el as HTMLElement).style.transform = 'translateY(0)';
              }, i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="features" ref={sectionRef} className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16 animate-on-scroll" style={{ opacity: 0, transform: 'translateY(30px)', transition: 'all 0.6s ease' }}>
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Автоматизируйте ключевые процессы
          </div>
          <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-4">
            Почему <span className="gradient-text">Aigentor</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Наши ИИ-агенты берут на себя рутинные задачи, чтобы вы могли сосредоточиться на росте бизнеса
          </p>
        </div>

        {/* Main features grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <div
                key={i}
                className="animate-on-scroll card-hover group bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:border-blue-100 cursor-pointer"
                style={{ opacity: 0, transform: 'translateY(30px)', transition: `all 0.6s ease ${i * 0.1}s` }}
              >
                <div className={`w-14 h-14 ${feature.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon size={26} />
                </div>
                <div className="inline-flex items-center gap-1 bg-gray-50 text-gray-600 px-2 py-0.5 rounded-full text-xs font-medium mb-3">
                  {feature.badge}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>

        {/* Capabilities */}
        <div className="animate-on-scroll" style={{ opacity: 0, transform: 'translateY(30px)', transition: 'all 0.6s ease 0.3s' }}>
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-black text-gray-900">Что может делать ИИ-агент</h3>
            <button
              onClick={onOpenForm}
              className="text-blue-600 font-semibold hover:text-blue-700 flex items-center gap-1 transition-colors"
            >
              Все возможности →
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {capabilities.map((cap, i) => {
              const Icon = cap.icon;
              return (
                <div
                  key={i}
                  className="flex items-start gap-4 p-5 bg-gray-50 rounded-2xl hover:bg-blue-50 hover:shadow-md transition-all duration-300 group cursor-pointer"
                >
                  <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <Icon size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{cap.label}</h4>
                    <p className="text-sm text-gray-600 leading-relaxed">{cap.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12 animate-on-scroll" style={{ opacity: 0, transform: 'translateY(20px)', transition: 'all 0.6s ease 0.4s' }}>
          <button
            onClick={onOpenForm}
            className="btn-primary"
          >
            Обсудить кейс →
          </button>
        </div>
      </div>
    </section>
  );
}
