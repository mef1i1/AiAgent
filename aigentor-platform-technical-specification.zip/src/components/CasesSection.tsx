import { useState, useRef, useEffect } from 'react';
import { Play, Pause, Phone, MessageSquare, Volume2 } from 'lucide-react';

const industries = [
  { id: 'construction', label: 'Строительство', emoji: '🏗️' },
  { id: 'consulting', label: 'Консалтинг', emoji: '💼' },
  { id: 'realty', label: 'Риелторство', emoji: '🏠' },
  { id: 'services', label: 'Услуги', emoji: '⚙️' },
  { id: 'production', label: 'Производство', emoji: '🏭' },
];

const casesData: Record<string, { voice: any[]; text: any[] }> = {
  construction: {
    voice: [
      {
        title: 'Автоматический прём входящих звонков',
        task: 'Строительная компания получала 300+ звонков в день. Менеджеры не успевали отвечать — терялись лиды.',
        solution: 'Развернули голосового ИИ-агента, который принимает звонки 24/7, квалифицирует клиентов и записывает на встречу.',
        result: '+47% конверсии, 0 пропущенных звонков, экономия 2 ставки менеджера',
        duration: '1:23',
        metrics: [{ label: 'Конверсия', value: '+47%' }, { label: 'Сэкономлено', value: '84 000 ₽/мес' }, { label: 'Звонков обработано', value: '9 200+' }],
      },
    ],
    text: [
      {
        title: 'ИИ-агент в Telegram для квалификации заявок',
        task: 'Клиенты писали в Telegram, но менеджеры отвечали с задержкой в 2-4 часа.',
        solution: 'Текстовый агент мгновенно квалифицирует запрос, собирает данные и передаёт горячего лида менеджеру.',
        result: 'Время первого ответа: 3 секунды. Конверсия в лид: 38%.',
        dialog: [
          { side: 'client', text: 'Здравствуйте, интересует строительство дома под ключ' },
          { side: 'agent', text: 'Добрый день! Рад помочь. Какой примерный бюджет и площадь дома вас интересуют?' },
          { side: 'client', text: 'Бюджет 8 млн, хочу 150 кв.м, одноэтажный' },
          { side: 'agent', text: 'Отлично! Это реализуемо. Когда планируете начать строительство? Наш специалист свяжется с вами в течение 30 минут.' },
        ],
        metrics: [{ label: 'Время ответа', value: '3 сек' }, { label: 'Конверсия в лид', value: '38%' }, { label: 'Диалогов в день', value: '120+' }],
      },
    ],
  },
  consulting: {
    voice: [
      {
        title: 'Первичная квалификация клиентов консалтинговой фирмы',
        task: 'Партнёры консалтинга тратили по 2 часа в день на первичные звонки с неквалифицированными лидами.',
        solution: 'ИИ-агент проводит первичный опрос, определяет потребность и бюджет, передаёт только целевых клиентов.',
        result: 'Партнёры экономят 40+ часов в месяц. Только целевые встречи.',
        duration: '2:05',
        metrics: [{ label: 'Время партнёров', value: '-40 часов/мес' }, { label: 'Целевые лиды', value: '+62%' }, { label: 'Стоимость лида', value: '-55%' }],
      },
    ],
    text: [
      {
        title: 'WhatsApp-агент для юридического консалтинга',
        task: 'Клиенты задавали типовые вопросы — менеджеры тратили время на одинаковые ответы.',
        solution: 'ИИ-агент отвечает на типовые вопросы, консультирует по услугам и назначает онлайн-встречи.',
        dialog: [
          { side: 'client', text: 'Сколько стоит регистрация ООО?' },
          { side: 'agent', text: 'Регистрация ООО "под ключ" — от 8 500 ₽, срок 5 рабочих дней. Включает подготовку документов и сопровождение.' },
          { side: 'client', text: 'А что входит в пакет?' },
          { side: 'agent', text: 'Устав, решение учредителей, заявление Р11001, открытие расчётного счёта, печать. Записать вас на бесплатную консультацию?' },
        ],
        metrics: [{ label: 'Типовых вопросов', value: '94% решено' }, { label: 'Время ответа', value: '5 сек' }, { label: 'NPS', value: '+28 пунктов' }],
      },
    ],
  },
  realty: {
    voice: [
      {
        title: 'Обработка входящих звонков в агентстве недвижимости',
        task: 'Агентство получало 500+ звонков в месяц. Менеджеры пропускали до 30% из-за занятости.',
        solution: 'Голосовой агент принимает все звонки, выясняет параметры объекта и бюджет, передаёт горячих клиентов.',
        result: '0 пропущенных. Конверсия выросла с 12% до 28%.',
        duration: '1:45',
        metrics: [{ label: 'Пропущенных', value: '0%' }, { label: 'Конверсия', value: '+16%' }, { label: 'Сделок в мес', value: '+8 сделок' }],
      },
    ],
    text: [
      {
        title: 'Telegram-бот для подбора недвижимости',
        task: 'Клиенты хотят быстро получить варианты по своим критериям без долгих переговоров.',
        solution: 'Агент собирает параметры, мгновенно показывает подходящие объекты из базы, назначает показ.',
        dialog: [
          { side: 'client', text: 'Ищу 2-комнатную квартиру в Москве' },
          { side: 'agent', text: 'Помогу подобрать! Какой район и бюджет? Первичка или вторичка?' },
          { side: 'client', text: 'ЦАО, до 12 млн, не важно' },
          { side: 'agent', text: 'Нашёл 14 вариантов по вашим критериям. Прислать топ-3 с фото? Могу записать на просмотр на этой неделе.' },
        ],
        metrics: [{ label: 'Вариантов в сек', value: '14' }, { label: 'Конверсия в показ', value: '41%' }, { label: 'Сделок через бота', value: '35%' }],
      },
    ],
  },
  services: {
    voice: [
      {
        title: 'Запись клиентов на услуги через голосового агента',
        task: 'Салон красоты терял клиентов — запись через телефон занимала 5-10 мин, люди вешали трубку.',
        solution: 'ИИ-агент записывает на услуги за 60 секунд, подтверждает запись и напоминает за день.',
        result: 'Отменённых записей -65%, загрузка мастеров +23%.',
        duration: '0:58',
        metrics: [{ label: 'Время записи', value: '60 сек' }, { label: 'Отмен', value: '-65%' }, { label: 'Загрузка', value: '+23%' }],
      },
    ],
    text: [
      {
        title: 'ИИ-поддержка клиентов сервисного центра',
        task: 'Клиенты сервисного центра постоянно спрашивали о статусе ремонта.',
        solution: 'Агент автоматически сообщает статус заказа, стоимость и дату готовности.',
        dialog: [
          { side: 'client', text: 'Хочу узнать статус ремонта, заказ #4521' },
          { side: 'agent', text: 'Заказ #4521: Ноутбук Lenovo. Статус: диагностика завершена, заменяем матрицу. Готовность — завтра в 16:00. Стоимость: 4 800 ₽.' },
          { side: 'client', text: 'Отлично, спасибо!' },
          { side: 'agent', text: 'Пожалуйста! Уведомим вас, когда ноутбук будет готов. Оплата при получении.' },
        ],
        metrics: [{ label: 'Обращений решено', value: '89%' }, { label: 'Звонков в поддержку', value: '-70%' }, { label: 'CSI', value: '4.9/5' }],
      },
    ],
  },
  production: {
    voice: [
      {
        title: 'Автоматический обзвон базы B2B клиентов',
        task: 'Производственная компания имела базу 2000 потенциальных клиентов. Менеджеры обзванивали по 20 в день.',
        solution: 'ИИ-агент делает до 500 исходящих звонков в день, квалифицирует интерес и передаёт тёплых лидов.',
        result: 'База прозвонена за 4 дня вместо 3 месяцев. Выявлено 180 горячих лидов.',
        duration: '1:34',
        metrics: [{ label: 'Звонков в день', value: '500+' }, { label: 'Горячих лидов', value: '180' }, { label: 'Экономия времени', value: '×15' }],
      },
    ],
    text: [
      {
        title: 'Email-агент для обработки входящих заявок B2B',
        task: 'Отдел продаж не успевал отвечать на email-запросы от производственников.',
        solution: 'ИИ-агент читает входящие письма, извлекает суть, готовит ответы с КП и передаёт менеджеру на одобрение.',
        dialog: [
          { side: 'client', text: 'Добрый день, нужно 500 кг полиэтилена LDPE, плёнка 100 мкм. Есть в наличии?' },
          { side: 'agent', text: 'Добрый день! Да, в наличии 2 тонны. Цена: 185 ₽/кг при объёме от 500 кг. Отгрузка в течение 2 рабочих дней. Выставить счёт?' },
          { side: 'client', text: 'Да, выставляйте на ООО "Техпром"' },
          { side: 'agent', text: 'Отлично! Пришлите реквизиты — выставим счёт в течение часа. Наш менеджер свяжется для уточнения деталей.' },
        ],
        metrics: [{ label: 'Время ответа', value: '< 5 мин' }, { label: 'Конверсия', value: '+34%' }, { label: 'Писем в день', value: '200+' }],
      },
    ],
  },
};

function AudioPlayer({ duration }: { duration: string }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(80);
  const intervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  const toggle = () => {
    if (!playing) {
      intervalRef.current = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(intervalRef.current);
            setPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 500);
      setPlaying(true);
    } else {
      clearInterval(intervalRef.current);
      setPlaying(false);
    }
  };

  useEffect(() => () => clearInterval(intervalRef.current), []);

  return (
    <div className="bg-gray-900 rounded-2xl p-4 flex items-center gap-4">
      <button onClick={toggle} className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors flex-shrink-0">
        {playing ? <Pause size={16} className="text-white" /> : <Play size={16} className="text-white ml-0.5" />}
      </button>
      <div className="flex-1">
        <div className="flex justify-between text-xs text-gray-400 mb-1">
          <span>Демо-запись звонка</span>
          <span>{duration}</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={progress}
          onChange={e => setProgress(Number(e.target.value))}
          className="w-full"
          style={{
            background: `linear-gradient(to right, #2563EB 0%, #2563EB ${progress}%, #374151 ${progress}%, #374151 100%)`
          }}
        />
      </div>
      <div className="flex items-center gap-1 flex-shrink-0">
        <Volume2 size={14} className="text-gray-400" />
        <input
          type="range"
          min="0"
          max="100"
          value={volume}
          onChange={e => setVolume(Number(e.target.value))}
          className="w-16"
          style={{
            background: `linear-gradient(to right, #6b7280 0%, #6b7280 ${volume}%, #374151 ${volume}%, #374151 100%)`
          }}
        />
      </div>
    </div>
  );
}

function Dialog({ messages }: { messages: { side: string; text: string }[] }) {
  return (
    <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
      {messages.map((msg, i) => (
        <div key={i} className={`flex ${msg.side === 'client' ? 'justify-end' : 'justify-start'}`}>
          <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm ${
            msg.side === 'client'
              ? 'bg-blue-600 text-white rounded-br-sm'
              : 'bg-gray-100 text-gray-800 rounded-bl-sm'
          }`}>
            {msg.side === 'agent' && <div className="text-xs font-bold text-blue-600 mb-0.5">ИИ-агент</div>}
            {msg.text}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function CasesSection({ onOpenForm }: { onOpenForm: () => void }) {
  const [activeIndustry, setActiveIndustry] = useState('construction');
  const [activeTab, setActiveTab] = useState<'voice' | 'text'>('voice');

  const cases = casesData[activeIndustry];
  const currentCase = cases[activeTab][0];

  return (
    <section id="cases" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Кейсы и демонстрация
          </div>
          <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-4">
            Реальные результаты<br />
            <span className="gradient-text">в вашей отрасли</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Послушайте реальные записи звонков и диалоги ИИ-агентов
          </p>
        </div>

        {/* Industry tabs */}
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {industries.map(ind => (
            <button
              key={ind.id}
              onClick={() => setActiveIndustry(ind.id)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 ${
                activeIndustry === ind.id
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-200'
                  : 'bg-white text-gray-600 hover:bg-blue-50 border border-gray-200'
              }`}
            >
              {ind.emoji} {ind.label}
            </button>
          ))}
        </div>

        {/* Voice/Text tabs */}
        <div className="flex gap-2 justify-center mb-8">
          <button
            onClick={() => setActiveTab('voice')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all ${
              activeTab === 'voice' ? 'tab-active shadow-md' : 'tab-inactive border border-gray-200'
            }`}
          >
            <Phone size={16} /> Голосовые агенты
          </button>
          <button
            onClick={() => setActiveTab('text')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all ${
              activeTab === 'text' ? 'tab-active shadow-md' : 'tab-inactive border border-gray-200'
            }`}
          >
            <MessageSquare size={16} /> Текстовые агенты
          </button>
        </div>

        {/* Case content */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left: Case description */}
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 card-hover">
            <div className="mb-6">
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold mb-4 ${
                activeTab === 'voice' ? 'bg-blue-50 text-blue-700' : 'bg-purple-50 text-purple-700'
              }`}>
                {activeTab === 'voice' ? '🎙️ Голосовой агент' : '💬 Текстовый агент'}
              </div>
              <h3 className="text-xl font-black text-gray-900 mb-4">{currentCase.title}</h3>
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-red-50 text-red-500 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-sm">❌</div>
                <div>
                  <p className="font-semibold text-gray-700 text-sm mb-1">Задача / проблема</p>
                  <p className="text-gray-600 text-sm">{currentCase.task}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-blue-50 text-blue-500 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-sm">⚡</div>
                <div>
                  <p className="font-semibold text-gray-700 text-sm mb-1">Решение</p>
                  <p className="text-gray-600 text-sm">{currentCase.solution}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-green-50 text-green-500 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-sm">✅</div>
                <div>
                  <p className="font-semibold text-gray-700 text-sm mb-1">Результат</p>
                  <p className="text-gray-600 text-sm font-semibold">{currentCase.result}</p>
                </div>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              {currentCase.metrics.map((m: any, i: number) => (
                <div key={i} className="bg-gray-50 rounded-xl p-3 text-center">
                  <div className="text-lg font-black text-blue-600">{m.value}</div>
                  <div className="text-xs text-gray-500">{m.label}</div>
                </div>
              ))}
            </div>

            <button
              onClick={onOpenForm}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors text-sm"
            >
              Обсудить мой кейс →
            </button>
          </div>

          {/* Right: Demo */}
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
            <h4 className="font-black text-gray-900 mb-4">
              {activeTab === 'voice' ? '🎙️ Запись демо-звонка' : '💬 Пример диалога'}
            </h4>

            {activeTab === 'voice' ? (
              <div>
                <AudioPlayer duration={currentCase.duration} />
                <div className="mt-4 p-4 bg-blue-50 rounded-xl">
                  <p className="text-blue-700 text-sm font-semibold mb-2">📞 Позвоните ИИ прямо сейчас:</p>
                  <a
                    href="tel:+74951234567"
                    className="flex items-center gap-2 text-blue-800 font-black text-xl hover:text-blue-900 transition-colors"
                  >
                    <Phone size={20} /> +7 (495) 123-45-67
                  </a>
                  <p className="text-blue-600/70 text-xs mt-1">Тестовый номер · Бесплатно</p>
                </div>
                <a
                  href="tel:+74951234567"
                  className="mt-4 w-full flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-xl font-bold hover:bg-green-600 transition-colors"
                >
                  <Phone size={16} /> Позвонить ИИ прямо сейчас
                </a>
              </div>
            ) : (
              <div>
                <div className="bg-gray-50 rounded-2xl p-4 mb-4">
                  <div className="flex items-center gap-2 mb-3 pb-3 border-b border-gray-200">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-bold">A</span>
                    </div>
                    <div>
                      <div className="text-sm font-bold text-gray-800">ИИ-агент Aigentor</div>
                      <div className="text-xs text-green-500">● Онлайн</div>
                    </div>
                  </div>
                  <Dialog messages={currentCase.dialog} />
                </div>
                <button
                  onClick={onOpenForm}
                  className="w-full flex items-center justify-center gap-2 bg-blue-100 text-blue-700 py-3 rounded-xl font-bold hover:bg-blue-200 transition-colors text-sm"
                >
                  <MessageSquare size={16} /> Пообщаться с тестовым агентом
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
