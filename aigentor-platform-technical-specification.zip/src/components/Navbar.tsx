import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  onOpenForm: () => void;
  onNavigate?: (section: string) => void;
}

export default function Navbar({ onOpenForm, onNavigate }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    setMobileOpen(false);
    onNavigate?.(id);
  };

  const links = [
    { label: 'Главная', id: 'hero' },
    { label: 'Возможности', id: 'features' },
    { label: 'Агенты', id: 'cases' },
    { label: 'Кейсы', id: 'cases' },
    { label: 'Тарифы', id: 'calculator' },
    { label: 'О компании', id: 'about' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass shadow-lg py-3' : 'py-5 bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button onClick={() => scrollTo('hero')} className="flex items-center gap-2 group">
            <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center group-hover:bg-blue-700 transition-colors">
              <span className="text-white font-black text-lg">A</span>
            </div>
            <div>
              <span className="text-xl font-black text-gray-900">Aigentor</span>
              <span className="block text-[10px] text-gray-400 font-medium -mt-1 tracking-widest uppercase">Creative Lab</span>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {links.map(link => (
              <button
                key={link.label}
                onClick={() => scrollTo(link.id)}
                className="nav-link px-4 py-2 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 text-sm font-medium"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <button
              onClick={() => window.location.href = '#dashboard'}
              className="text-gray-600 font-medium text-sm hover:text-blue-600 transition-colors px-4 py-2"
            >
              Войти
            </button>
            <button
              onClick={onOpenForm}
              className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-all duration-200 hover:scale-105 shadow-lg shadow-blue-600/30"
            >
              Связаться с нами
              <span>→</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden glass border-t border-gray-100 mt-2 mx-4 rounded-2xl p-4 mobile-menu">
          <div className="flex flex-col gap-1">
            {links.map(link => (
              <button
                key={link.label}
                onClick={() => scrollTo(link.id)}
                className="text-left px-4 py-3 rounded-xl text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors font-medium"
              >
                {link.label}
              </button>
            ))}
            <div className="border-t border-gray-100 mt-2 pt-2 flex flex-col gap-2">
              <button className="text-center px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 font-medium">
                Войти
              </button>
              <button
                onClick={() => { onOpenForm(); setMobileOpen(false); }}
                className="btn-primary text-center py-3 text-base"
              >
                Связаться с нами →
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
