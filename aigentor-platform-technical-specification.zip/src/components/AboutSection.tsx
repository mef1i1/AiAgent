import { useRef, useEffect } from 'react';
import { Users, Award, TrendingUp, Zap } from 'lucide-react';

const achievements = [
  { icon: '🤖', value: '2+', label: 'Года в ИИ-автоматизации' },
  { icon: '💼', value: '100+', label: 'Реализованных проектов' },
  { icon: '📈', value: '50М+', label: 'Рублей сэкономлено клиентам' },
  { icon: '⭐', value: '4.9/5', label: 'Средняя оценка клиентов' },
];

const expertises = [
  { icon: Zap, label: 'ИИ-автоматизация', desc: 'GPT-4, голосовые агенты, NLP' },
  { icon: TrendingUp, label: 'Маркетинг и трафик', desc: 'Performance, SEO, Telegram-каналы' },
  { icon: Users, label: 'Бизнес-консалтинг', desc: 'Оптимизация процессов, CRM' },
  { icon: Award, label: 'Продуктовый опыт', desc: 'SaaS, B2B, системная архитектура' },
];

export default function AboutSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.animate-on-scroll').forEach((el, i) => {
            setTimeout(() => {
              (el as HTMLElement).style.opacity = '1';
              (el as HTMLElement).style.transform = 'none';
            }, i * 150);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Text */}
          <div>
            <div
              className="animate-on-scroll"
              style={{ opacity: 0, transform: 'translateX(-30px)', transition: 'all 0.7s ease' }}
            >
              <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                О нас
              </div>
              <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-6 leading-tight">
                Кто создаёт автоматизацию<br />
                <span className="gradient-text">для вашего бизнеса</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Мы — Георгий и Артём, основатели Aigentor. Более <strong>2 лет</strong> создаём ИИ-агентов для малого и среднего бизнеса в России.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                За это время мы прошли путь от экспериментов с первыми чат-ботами до запуска полноценных голосовых и текстовых агентов на базе GPT-4, которые обрабатывают тысячи обращений ежедневно.
              </p>

              {/* Expertise */}
              <div className="grid sm:grid-cols-2 gap-4 mb-8">
                {expertises.map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl hover:bg-blue-50 transition-colors group">
                      <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <Icon size={18} />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900 text-sm">{item.label}</p>
                        <p className="text-gray-500 text-xs">{item.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Social links */}
              <div className="flex items-center gap-3">
                <span className="text-gray-500 text-sm">Наши соцсети:</span>
                {[
                  { label: 'Telegram', href: 'https://t.me/aigentor', emoji: '✈️' },
                  { label: 'YouTube', href: 'https://youtube.com/@aigentor', emoji: '▶️' },
                  { label: 'VK', href: 'https://vk.com/aigentor', emoji: '💙' },
                ].map((social, i) => (
                  <a
                    key={i}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-blue-50 hover:text-blue-700 transition-all"
                  >
                    {social.emoji} {social.label}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Photo + stats */}
          <div
            className="animate-on-scroll"
            style={{ opacity: 0, transform: 'translateX(30px)', transition: 'all 0.7s ease 0.2s' }}
          >
            {/* Photo */}
            <div className="relative mb-8">
              <div className="rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/images/founders.png"
                  alt="Основатели Aigentor — Георгий и Артём"
                  className="w-full h-72 object-cover object-top"
                />
              </div>
              {/* Name overlay */}
              <div className="absolute bottom-4 left-4 right-4 glass rounded-2xl px-4 py-3 flex justify-center gap-8">
                <div className="text-center">
                  <p className="font-black text-gray-900">Георгий</p>
                  <p className="text-xs text-gray-500">Co-founder & CEO</p>
                </div>
                <div className="w-px bg-gray-200" />
                <div className="text-center">
                  <p className="font-black text-gray-900">Артём</p>
                  <p className="text-xs text-gray-500">Co-founder & CTO</p>
                </div>
              </div>
            </div>

            {/* Achievement stats */}
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((item, i) => (
                <div key={i} className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-5 text-center card-hover border border-blue-100">
                  <div className="text-3xl mb-2">{item.icon}</div>
                  <div className="text-2xl font-black text-blue-700">{item.value}</div>
                  <div className="text-xs text-gray-500 mt-1">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
