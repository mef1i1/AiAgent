const navLinks = [
  { label: 'Главная', id: 'hero' },
  { label: 'Возможности', id: 'features' },
  { label: 'Кейсы', id: 'cases' },
  { label: 'Калькулятор', id: 'calculator' },
  { label: 'О компании', id: 'about' },
  { label: 'Контакты', id: 'contact' },
];

const legalLinks = [
  { label: 'Политика конфиденциальности', href: '#' },
  { label: 'Пользовательское соглашение', href: '#' },
  { label: 'Согласие на обработку ПД', href: '#' },
];

export default function Footer() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-10 pb-12 border-b border-gray-800">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-black text-xl">A</span>
              </div>
              <div>
                <span className="text-xl font-black">Aigentor</span>
                <span className="block text-[10px] text-gray-400 tracking-widest uppercase -mt-1">Creative Lab</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-5">
              Платформа автоматизации бизнеса с помощью ИИ-агентов. Готовые решения под ключ для МСБ.
            </p>
            <div className="flex gap-3">
              {[
                { label: 'Telegram', href: 'https://t.me/aigentor', emoji: '✈️' },
                { label: 'YouTube', href: 'https://youtube.com/@aigentor', emoji: '▶️' },
                { label: 'VK', href: 'https://vk.com/aigentor', emoji: '💙' },
              ].map((s, i) => (
                <a
                  key={i}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 bg-gray-800 hover:bg-blue-600 rounded-xl flex items-center justify-center text-sm transition-all"
                  title={s.label}
                >
                  {s.emoji}
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-bold text-white mb-4">Навигация</h4>
            <ul className="space-y-2.5">
              {navLinks.map(link => (
                <li key={link.label}>
                  <button
                    onClick={() => scrollTo(link.id)}
                    className="text-gray-400 hover:text-white text-sm transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-bold text-white mb-4">Правовая информация</h4>
            <ul className="space-y-2.5">
              {legalLinks.map(link => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-white text-sm transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contacts */}
          <div>
            <h4 className="font-bold text-white mb-4">Контакты</h4>
            <div className="space-y-3">
              <div>
                <p className="text-gray-500 text-xs uppercase tracking-wide mb-1">Телефон</p>
                <a href="tel:+74951234567" className="text-gray-300 hover:text-white text-sm transition-colors">
                  +7 (495) 123-45-67
                </a>
              </div>
              <div>
                <p className="text-gray-500 text-xs uppercase tracking-wide mb-1">Email</p>
                <a href="mailto:hello@aigentor.ru" className="text-gray-300 hover:text-white text-sm transition-colors">
                  hello@aigentor.ru
                </a>
              </div>
              <div>
                <p className="text-gray-500 text-xs uppercase tracking-wide mb-1">Режим работы</p>
                <p className="text-gray-300 text-sm">Пн-Пт: 9:00–20:00 МСК</p>
              </div>
              <div className="pt-2">
                <div className="inline-flex items-center gap-1.5 bg-green-900/40 text-green-400 px-3 py-1.5 rounded-lg text-xs font-semibold border border-green-800">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                  Онлайн · Ответим за 1 час
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-gray-500 text-sm">
            © 2024 Aigentor. Все права защищены.
          </div>
          <div className="flex flex-col md:flex-row items-center gap-4 text-gray-500 text-xs text-center">
            <span>ИНН: 7701234567</span>
            <span className="hidden md:block">·</span>
            <span>ОГРН: 1247700123456</span>
            <span className="hidden md:block">·</span>
            <span>Данные хранятся на серверах в РФ</span>
            <span className="hidden md:block">·</span>
            <span className="text-green-500">152-ФЗ ✓</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
