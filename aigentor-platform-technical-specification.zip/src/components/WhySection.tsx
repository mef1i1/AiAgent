import { useRef, useEffect } from 'react';
import { CheckCircle, TrendingUp, Clock, DollarSign, Shield, Zap } from 'lucide-react';

const problems = [
  'Клиенты хотят быстрых ответов и решений здесь и сейчас',
  'Конкуренты уже автоматизируют процессы',
  'Ручная работа = ошибки, задержки, потерянные деньги',
  'ИИ-агенты работают 24/7 и усиливают ваш бизнес',
];

const benefits = [
  { icon: DollarSign, color: 'text-green-600 bg-green-100', title: 'Снижение затрат', desc: 'Заменяет 3–6 сотрудников по обзвону и обработке заявок' },
  { icon: TrendingUp, color: 'text-blue-600 bg-blue-100', title: 'Рост продаж', desc: 'Больше обработанных лидов и конверсий без увеличения штата' },
  { icon: Zap, color: 'text-yellow-600 bg-yellow-100', title: 'Скорость', desc: 'Мгновенные ответы и решения — 0 секунд ожидания' },
  { icon: Shield, color: 'text-purple-600 bg-purple-100', title: 'Стабильность', desc: 'Никаких выходных, отпусков и больничных у агента' },
  { icon: Clock, color: 'text-cyan-600 bg-cyan-100', title: 'Масштабируемость', desc: 'Легко расширяется под ваш рост: 10 или 10 000 звонков' },
  { icon: CheckCircle, color: 'text-orange-600 bg-orange-100', title: 'Контроль', desc: 'Полная аналитика, транскрипции и логи в личном кабинете' },
];

export default function WhySection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.why-item').forEach((el, i) => {
            setTimeout(() => {
              (el as HTMLElement).style.opacity = '1';
              (el as HTMLElement).style.transform = 'none';
            }, i * 100);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-gradient-to-br from-slate-900 via-blue-950 to-purple-950 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-400 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-64 h-64 bg-purple-400 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Why now */}
          <div>
            <div
              className="why-item"
              style={{ opacity: 0, transform: 'translateX(-30px)', transition: 'all 0.7s ease' }}
            >
              <div className="inline-flex items-center gap-2 bg-white/10 text-white px-4 py-2 rounded-full text-sm font-semibold mb-6 border border-white/20">
                5️⃣ Почему это актуально
              </div>
              <h2 className="text-4xl lg:text-5xl font-black text-white mb-8 leading-tight">
                Кто быстрее внедрил ИИ —<br />
                <span className="text-blue-400">тот забирает рынок</span>
              </h2>

              <div className="space-y-4 mb-8">
                {problems.map((prob, i) => (
                  <div key={i} className="flex items-start gap-3 why-item" style={{ opacity: 0, transform: 'translateX(-20px)', transition: `all 0.5s ease ${i * 0.1}s` }}>
                    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3.5 h-3.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <p className="text-blue-100 text-base">{prob}</p>
                  </div>
                ))}
              </div>

              <div className="bg-blue-600/30 border border-blue-500/40 rounded-2xl p-5">
                <p className="text-white font-black text-lg">
                  🚀 ИИ-агент — это инструмент,<br />
                  <span className="text-blue-300">который напрямую увеличивает вашу прибыль.</span>
                </p>
              </div>
            </div>
          </div>

          {/* Right: Benefits grid */}
          <div>
            <div
              className="why-item mb-6"
              style={{ opacity: 0, transform: 'translateX(30px)', transition: 'all 0.7s ease 0.2s' }}
            >
              <div className="inline-flex items-center gap-2 bg-white/10 text-white px-4 py-2 rounded-full text-sm font-semibold mb-6 border border-white/20">
                6️⃣ Что вы получаете
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {benefits.map((benefit, i) => {
                const Icon = benefit.icon;
                return (
                  <div
                    key={i}
                    className="why-item bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-5 hover:bg-white/15 transition-all card-hover"
                    style={{ opacity: 0, transform: 'translateY(20px)', transition: `all 0.5s ease ${i * 0.1}s` }}
                  >
                    <div className={`w-10 h-10 ${benefit.color} rounded-xl flex items-center justify-center mb-3`}>
                      <Icon size={20} />
                    </div>
                    <h4 className="text-white font-bold mb-1">{benefit.title}</h4>
                    <p className="text-blue-200/80 text-sm leading-relaxed">{benefit.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
