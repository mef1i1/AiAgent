import { useState, useEffect } from 'react';
import { X, Send, CheckCircle } from 'lucide-react';

const industries = [
  'Строительство', 'Консалтинг', 'Риелторство', 'Услуги',
  'Производство', 'Торговля', 'Медицина', 'Образование', 'Другое'
];

interface FormModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefillData?: { calls?: number; salary?: number; savings?: number };
}

export default function FormModal({ isOpen, onClose, prefillData }: FormModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    industry: '',
    comment: '',
    agree: false,
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (prefillData && prefillData.savings) {
      setFormData(prev => ({
        ...prev,
        comment: `Расчёт из калькулятора:\n- Звонков в мес: ${prefillData.calls}\n- Ожидаемая экономия: ${prefillData.savings?.toLocaleString('ru-RU')} ₽/мес`
      }));
    }
  }, [prefillData]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Введите имя';
    if (!formData.phone || formData.phone.replace(/\D/g, '').length < 10) newErrors.phone = 'Введите корректный телефон';
    if (!formData.industry) newErrors.industry = 'Выберите нишу';
    if (!formData.agree) newErrors.agree = 'Необходимо согласие';
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setErrors({});
    setSubmitted(true);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '');
    if (val.startsWith('8')) val = '7' + val.slice(1);
    if (!val.startsWith('7')) val = '7' + val;
    val = val.slice(0, 11);
    let formatted = '+7';
    if (val.length > 1) formatted += ' (' + val.slice(1, 4);
    if (val.length >= 4) formatted += ') ' + val.slice(4, 7);
    if (val.length >= 7) formatted += '-' + val.slice(7, 9);
    if (val.length >= 9) formatted += '-' + val.slice(9, 11);
    setFormData(prev => ({ ...prev, phone: formatted }));
  };

  const handleClose = () => {
    setSubmitted(false);
    setErrors({});
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      <div className="modal-backdrop absolute inset-0" onClick={handleClose} />
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md z-10 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white px-6 pt-6 pb-4 border-b border-gray-100 rounded-t-3xl flex items-center justify-between">
          <div>
            <h3 className="text-xl font-black text-gray-900">
              {submitted ? 'Заявка отправлена! 🎉' : 'Запустить бесплатный тест'}
            </h3>
            {!submitted && <p className="text-sm text-gray-500">Ответим в течение 1 часа</p>}
          </div>
          <button
            onClick={handleClose}
            className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-6">
          {submitted ? (
            <div className="text-center py-4">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={40} />
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Спасибо, {formData.name}! Наш менеджер свяжется с вами по номеру {formData.phone} в ближайшее время.
              </p>
              <div className="bg-blue-50 rounded-2xl p-4 text-left mb-6">
                <p className="text-blue-700 font-semibold text-sm mb-2">Что будет дальше:</p>
                <ol className="space-y-1.5 text-sm text-blue-600">
                  <li>1. Звонок от менеджера (в течение часа)</li>
                  <li>2. Демонстрация агента 15 мин</li>
                  <li>3. Бесплатный тест 7 дней</li>
                  <li>4. Запуск в работу</li>
                </ol>
              </div>
              <button onClick={handleClose} className="btn-primary w-full">
                Закрыть
              </button>
            </div>
          ) : (
            <>
              {prefillData?.savings && (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-6">
                  <p className="text-blue-800 text-sm font-bold mb-1">💰 Ваш расчёт из калькулятора:</p>
                  <p className="text-blue-700 text-sm">
                    Ожидаемая экономия: <strong>{prefillData.savings.toLocaleString('ru-RU')} ₽/мес</strong>
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Имя *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                    placeholder="Ваше имя"
                    className={`w-full px-4 py-3 rounded-xl border-2 focus:outline-none focus:border-blue-500 transition-colors ${
                      errors.name ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'
                    }`}
                  />
                  {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Телефон *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={handlePhoneChange}
                    placeholder="+7 (___) ___-__-__"
                    className={`w-full px-4 py-3 rounded-xl border-2 focus:outline-none focus:border-blue-500 transition-colors ${
                      errors.phone ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'
                    }`}
                  />
                  {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Ниша бизнеса *</label>
                  <select
                    value={formData.industry}
                    onChange={e => setFormData(p => ({ ...p, industry: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-xl border-2 focus:outline-none focus:border-blue-500 transition-colors ${
                      errors.industry ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'
                    }`}
                  >
                    <option value="">Выберите отрасль</option>
                    {industries.map(ind => <option key={ind} value={ind}>{ind}</option>)}
                  </select>
                  {errors.industry && <p className="text-red-500 text-xs mt-1">{errors.industry}</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Комментарий</label>
                  <textarea
                    value={formData.comment}
                    onChange={e => setFormData(p => ({ ...p, comment: e.target.value }))}
                    placeholder="О вашем бизнесе..."
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-gray-50 focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  />
                </div>

                <label className={`flex items-start gap-3 cursor-pointer`}>
                  <div className="relative flex-shrink-0 mt-0.5">
                    <input
                      type="checkbox"
                      checked={formData.agree}
                      onChange={e => setFormData(p => ({ ...p, agree: e.target.checked }))}
                      className="sr-only"
                    />
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                      formData.agree ? 'bg-blue-600 border-blue-600' : errors.agree ? 'border-red-400' : 'border-gray-300'
                    }`}>
                      {formData.agree && (
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  </div>
                  <span className={`text-xs ${errors.agree ? 'text-red-500' : 'text-gray-500'}`}>
                    Согласен(на) на обработку персональных данных согласно{' '}
                    <a href="#" className="text-blue-600 hover:underline">Политике конфиденциальности</a>
                  </span>
                </label>
                {errors.agree && <p className="text-red-500 text-xs -mt-2">{errors.agree}</p>}

                <button type="submit" className="w-full btn-primary flex items-center justify-center gap-2">
                  <Send size={16} /> Отправить заявку
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
