import { useRef, useEffect } from 'react';
import { Search, Puzzle, Code, TestTube, Rocket } from 'lucide-react';

const steps = [
  {
    icon: Search,
    number: '01',
    title: 'Анализируем вашу нишу и задачи',
    desc: 'Проводим аудит бизнес-процессов, выявляем точки автоматизации и рассчитываем потенциальную экономию.',
    color: 'from-blue-500 to-blue-600',
    bg: 'bg-blue-50',
  },
  {
    icon: Puzzle,
    number: '02',
    title: 'Проектируем решение под результат',
    desc: 'Создаём архитектуру агента: сценарии диалогов, интеграции с вашими системами, логику обработки.',
    color: 'from-purple-500 to-purple-600',
    bg: 'bg-purple-50',
  },
  {
    icon: Code,
    number: '03',
    title: 'Разрабатываем систему',
    desc: 'Настраиваем ИИ-агента, обучаем на вашей базе знаний, подключаем телефонию и мессенджеры.',
    color: 'from-cyan-500 to-cyan-600',
    bg: 'bg-cyan-50',
  },
  {
    icon: TestTube,
    number: '04',
    title: 'Даём бесплатно протестировать',
    desc: 'Запускаем тестовый период — вы видите реальные результаты до оплаты. Никаких рисков.',
    color: 'from-green-500 to-green-600',
    bg: 'bg-green-50',
  },
  {
    icon: Rocket,
    number: '05',
    title: 'Внедряем под ключ',
    desc: 'Запускаем в production, обучаем вашу команду, обеспечиваем поддержку 24/7.',
    color: 'from-orange-500 to-orange-600',
    bg: 'bg-orange-50',
  },
];

export default function HowItWorksSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.step-card').forEach((el, i) => {
            setTimeout(() => {
              (el as HTMLElement).style.opacity = '1';
              (el as HTMLElement).style.transform = 'translateY(0)';
            }, i * 150);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="how" ref={sectionRef} className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Как мы работаем
          </div>
          <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-4">
            5 шагов до<br />
            <span className="gradient-text">работающего агента</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Без шаблонов. Под конкретную задачу. Индивидуальный подход — максимальный результат.
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6 mb-12">
          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <div
                key={i}
                className="step-card relative"
                style={{ opacity: 0, transform: 'translateY(30px)', transition: `all 0.6s ease ${i * 0.1}s` }}
              >
                {/* Connector line */}
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-[60%] w-[calc(100%-20px)] h-0.5 bg-gradient-to-r from-gray-200 to-gray-100 z-0" />
                )}

                <div className="relative z-10 text-center group">
                  <div className={`w-20 h-20 mx-auto mb-4 rounded-2xl ${step.bg} flex items-center justify-center group-hover:scale-110 transition-transform relative`}>
                    <div className={`w-full h-full rounded-2xl bg-gradient-to-br ${step.color} absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity`} />
                    <Icon size={28} className="relative z-10 text-gray-600 group-hover:text-white transition-colors" />
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-gray-900 text-white rounded-full flex items-center justify-center text-xs font-black">
                      {i + 1}
                    </div>
                  </div>
                  <h3 className="font-black text-gray-900 text-sm mb-2 leading-tight">{step.title}</h3>
                  <p className="text-gray-500 text-xs leading-relaxed">{step.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Trust badge */}
        <div className="flex justify-center">
          <div className="inline-flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-2xl px-6 py-4">
            <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center font-black text-lg">A</div>
            <div>
              <p className="font-bold text-gray-900">Без шаблонов. Под конкретную задачу.</p>
              <p className="text-gray-500 text-sm">Индивидуальный подход — максимальный результат.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
