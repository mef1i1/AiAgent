import { useState, useEffect, useRef } from 'react';
import { Calculator as CalcIcon, TrendingUp, Clock, DollarSign } from 'lucide-react';

interface CalculatorProps {
  onOpenForm: (data?: { calls: number; salary: number; savings: number }) => void;
}

export default function Calculator({ onOpenForm }: CalculatorProps) {
  const [calls, setCalls] = useState(1000);
  const [salary, setSalary] = useState(70000);
  const [animated, setAnimated] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Formula
  const avgDuration = 5; // minutes per call
  const hourlyRate = salary / 160; // 160 working hours/month
  const minuteRate = hourlyRate / 60;
  const automationRate = 0.7;

  const savedMoney = Math.round(calls * avgDuration * minuteRate * automationRate);
  const savedHours = Math.round((calls * avgDuration * automationRate) / 60);
  const savedEmployees = Math.round((calls * avgDuration * automationRate) / (160 * 60));
  const roi = Math.round((savedMoney / 15000) * 100); // assuming 15k/mo cost

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setAnimated(true); },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const formatNumber = (n: number) => n.toLocaleString('ru-RU');

  return (
    <section id="calculator" ref={sectionRef} className="py-24 bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-64 h-64 bg-blue-400 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-80 h-80 bg-purple-400 rounded-full blur-3xl" />
      </div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djZoLTZ2LTZoNnptMCAwaDZ2Nmg2di02aC02em0tNiAwdjZoLTZ2LTZoNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-white/10 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4 border border-white/20">
            <CalcIcon size={14} />
            Калькулятор выгоды
          </div>
          <h2 className="text-4xl lg:text-5xl font-black text-white mb-4">
            Узнайте, сколько времени и денег<br />
            <span className="text-blue-300">вы сэкономите</span>
          </h2>
          <p className="text-blue-200 text-lg max-w-2xl mx-auto">
            Передвигайте ползунки и смотрите на реальную экономию для вашего бизнеса
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Sliders */}
          <div className={`bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-8 transition-all duration-700 ${animated ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            {/* Slider 1: Calls */}
            <div className="mb-10">
              <div className="flex justify-between items-center mb-3">
                <label className="text-white font-semibold flex items-center gap-2">
                  <Phone size={16} className="text-blue-300" />
                  Звонков / обращений в месяц
                </label>
                <span className="text-2xl font-black text-blue-300">{formatNumber(calls)}</span>
              </div>
              <input
                type="range"
                min="100"
                max="10000"
                step="100"
                value={calls}
                onChange={e => setCalls(Number(e.target.value))}
                className="w-full"
                style={{
                  background: `linear-gradient(to right, #60a5fa 0%, #60a5fa ${((calls - 100) / 9900) * 100}%, rgba(255,255,255,0.2) ${((calls - 100) / 9900) * 100}%, rgba(255,255,255,0.2) 100%)`
                }}
              />
              <div className="flex justify-between text-blue-300/70 text-xs mt-1">
                <span>100</span>
                <span>10 000+</span>
              </div>
            </div>

            {/* Slider 2: Salary */}
            <div className="mb-10">
              <div className="flex justify-between items-center mb-3">
                <label className="text-white font-semibold flex items-center gap-2">
                  <DollarSign size={16} className="text-blue-300" />
                  Средняя зарплата менеджера
                </label>
                <span className="text-2xl font-black text-blue-300">{formatNumber(salary)} ₽</span>
              </div>
              <input
                type="range"
                min="40000"
                max="150000"
                step="5000"
                value={salary}
                onChange={e => setSalary(Number(e.target.value))}
                className="w-full"
                style={{
                  background: `linear-gradient(to right, #60a5fa 0%, #60a5fa ${((salary - 40000) / 110000) * 100}%, rgba(255,255,255,0.2) ${((salary - 40000) / 110000) * 100}%, rgba(255,255,255,0.2) 100%)`
                }}
              />
              <div className="flex justify-between text-blue-300/70 text-xs mt-1">
                <span>40 000 ₽</span>
                <span>150 000 ₽</span>
              </div>
            </div>

            {/* Assumptions */}
            <div className="bg-white/5 rounded-2xl p-4 border border-white/10">
              <p className="text-blue-200 text-sm font-medium mb-2">Параметры расчёта:</p>
              <div className="grid grid-cols-2 gap-3 text-xs text-blue-300/80">
                <div>⏱ Средняя длительность: {avgDuration} мин</div>
                <div>🤖 Автоматизация: 70%</div>
                <div>📊 Рабочих часов: 160/мес</div>
                <div>✅ Успешность агента: 95%</div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className={`transition-all duration-700 delay-200 ${animated ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            <div className="grid grid-cols-2 gap-4 mb-6">
              {/* Main savings */}
              <div className="col-span-2 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-6 text-white shadow-2xl">
                <div className="flex items-center gap-2 mb-2 opacity-80">
                  <TrendingUp size={18} />
                  <span className="text-sm font-semibold">Экономия ФОТ в месяц</span>
                </div>
                <div className="text-5xl font-black mb-1">
                  {formatNumber(savedMoney)} ₽
                </div>
                <div className="text-blue-200 text-sm">
                  за счёт автоматизации {Math.round(calls * automationRate)} звонков
                </div>
              </div>

              {/* Hours saved */}
              <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-5 text-white">
                <div className="flex items-center gap-2 mb-2 opacity-80">
                  <Clock size={16} />
                  <span className="text-xs font-semibold">Высвобождено времени</span>
                </div>
                <div className="text-3xl font-black text-blue-300">{formatNumber(savedHours)}</div>
                <div className="text-blue-200/70 text-xs mt-1">часов в месяц</div>
              </div>

              {/* Employees freed */}
              <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-5 text-white">
                <div className="flex items-center gap-2 mb-2 opacity-80">
                  <span className="text-base">👥</span>
                  <span className="text-xs font-semibold">Заменяет сотрудников</span>
                </div>
                <div className="text-3xl font-black text-purple-300">{Math.max(1, savedEmployees)}</div>
                <div className="text-blue-200/70 text-xs mt-1">менеджеров по обзвону</div>
              </div>

              {/* Annual savings */}
              <div className="col-span-2 bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-5 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold opacity-80 mb-1">💰 Экономия за год</p>
                    <p className="text-3xl font-black text-green-300">{formatNumber(savedMoney * 12)} ₽</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-semibold opacity-80 mb-1">📈 ROI</p>
                    <p className="text-3xl font-black text-yellow-300">{roi}%</p>
                  </div>
                </div>
                {/* Progress bar */}
                <div className="mt-3 progress-bar">
                  <div
                    className="progress-fill"
                    style={{ width: `${Math.min(100, roi)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* CTA */}
            <button
              onClick={() => onOpenForm({ calls, salary, savings: savedMoney })}
              className="w-full bg-white text-blue-700 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-blue-50 transition-all duration-300 hover:scale-105 shadow-2xl flex items-center justify-center gap-2"
            >
              Получить расчёт под мой бизнес →
            </button>
            <p className="text-center text-blue-300/70 text-sm mt-3">
              Бесплатно · Без обязательств · Ответ в течение часа
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Phone({ size, className }: { size: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}>
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.5a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .84h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 8.09a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
    </svg>
  );
}
