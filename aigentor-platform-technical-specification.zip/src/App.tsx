import { useState } from 'react';
import CustomCursor from './components/CustomCursor';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import FeaturesSection from './components/FeaturesSection';
import Calculator from './components/Calculator';
import CasesSection from './components/CasesSection';
import DashboardPreview from './components/DashboardPreview';
import AboutSection from './components/AboutSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import FormModal from './components/FormModal';
import DemoModal from './components/DemoModal';
import HowItWorksSection from './components/HowItWorksSection';
import WhySection from './components/WhySection';

interface PrefillData {
  calls?: number;
  salary?: number;
  savings?: number;
}

function App() {
  const [formOpen, setFormOpen] = useState(false);
  const [demoOpen, setDemoOpen] = useState(false);
  const [prefillData, setPrefillData] = useState<PrefillData | undefined>();

  const openForm = (data?: PrefillData) => {
    setPrefillData(data);
    setFormOpen(true);
  };

  return (
    <div className="min-h-screen">
      <CustomCursor />
      <Navbar onOpenForm={() => openForm()} />

      <main>
        <HeroSection onOpenForm={() => openForm()} onOpenDemo={() => setDemoOpen(true)} />
        <FeaturesSection onOpenForm={() => openForm()} />
        <HowItWorksSection />
        <WhySection />
        <Calculator onOpenForm={openForm} />
        <CasesSection onOpenForm={() => openForm()} />
        <DashboardPreview onOpenForm={() => openForm()} />
        <AboutSection />
        <ContactSection />
      </main>

      <Footer />

      <FormModal
        isOpen={formOpen}
        onClose={() => setFormOpen(false)}
        prefillData={prefillData}
      />
      <DemoModal
        isOpen={demoOpen}
        onClose={() => setDemoOpen(false)}
      />
    </div>
  );
}

export default App;
